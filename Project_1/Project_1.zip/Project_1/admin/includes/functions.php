<?php 

// function __autoload($class){
// 	$class = strtolower($class);

//     $the_path  = "includes/{$class}.php";

//     if(file_exists($the_path)){
//     	require_once($the_path);
//     }else{
//     	die("this file name {$class}.php was not found ...");
//     }


// }
/**
 * New updated version is with spl_autoload_register method, above the method no recommended by php.net team
 */
function classAutoloader($class){
	$class = strtolower($class);

    $the_path  = "includes/{$class}.php";

    if(is_file($the_path) && !class_exists($class)){
    	require_once $the_path;
    }

    // if(file_exists($the_path)){
    // 	require_once($the_path);
    // }else{
    // 	die("this file name {$class}.php was not found ...");
    // }

}
spl_autoload_register('classAutoloader');

function redirect($location){

    header("Location: {$location}");

}






?>