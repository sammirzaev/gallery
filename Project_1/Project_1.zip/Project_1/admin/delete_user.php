<?php include("includes/init.php"); ?>
<?php 
  if(!$session->is_signed_in()){
  redirect("login.php");
  } //redirection of page to login page if user not signed in
 ?>

 <?php 

if(empty($_GET["id"])){
  redirect("users.php");
}
$user = User::find_by_id($_GET["id"]);

if($user){
   $user->delete();
   redirect("users.php");
   $session->message("<div class='alert alert-danger' role='alert'> User has been deleted by ID:{$user->id}<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>");
}else{
  redirect("users.php");
  $session->message("<div class='alert alert-warning' role='alert'> User has not able to delete by ID:{$user->id}<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>");
}











?>