<?php include("includes/header.php"); ?>
<?php if(!$session->is_signed_in()){
  redirect("login.php");
  } //redirection of page to login page if user not signed in ?>

  <?php 
  $page = !empty($_GET["page"]) ? (int)$_GET["page"] : 1;
  $items_per_page = 10;
  $items_total_count = Photo::count_all();
  $paginate = new Paginate($page, $items_per_page, $items_total_count);

  $sql = "SELECT * FROM photos ";
  $sql .= "LIMIT {$items_per_page} ";
  $sql .= "OFFSET {$paginate->offset()}";
  $photos = Photo::find_by_query($sql);
  Photo::search($_POST["search"]);

   ?>
        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <?php include "includes/top_nav.php";?> 

            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->

            <?php include "includes/side_nav.php";?>
            
            <!-- /.navbar-collapse -->

        </nav>

        <div id="page-wrapper">
             <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">
                                PHOTOS
                                <small> </small>
                            </h1>
                            <?php echo $session->message; ?></div>
                            <div class="col-md-12">

                              <div class="row text-center">
                                <div class="col-md-8">
                                <ul class="pagination">
                        <?php 
                        if($paginate->page_total() > 1){
                          if($paginate->has_previous()){
                            echo "<li class='previous'>";
                            echo "<a href='photos.php?page={$paginate->previous()}'>";
                            echo "Previous</a></li>";
                          }
                          for ($i=max(1,$paginate->current_page - 3); $i <= min($paginate->page_total() +3, $paginate->page_total()); $i++) { 
                              if($i == $paginate->current_page){
                                echo "<li class='active'><a href='photos.php?page={$i}'>$i</a></li>";
                              }else{
                                echo "<li><a href='photos.php?page={$i}'>$i</a></li>";
                              }
                          }
                            if($paginate->has_next()){
                              echo "<li class='next'>"; 
                              echo "<a href='photos.php?page={$paginate->next()}'>";
                              echo "Next</a></li>";
                            }

                          } 
                          
                          ?>
                                    
                                </ul>
                              </div>
                              <div class="col-md-4" style="margin-top:20px;">
                                <form class="input-group" method="POST" action="" name="search" id="search_form">
                                  <input class="form-control" type="text" name="search" placeholder="Serch item...">
                                  <span class="input-group-btn">
                                     <button class="btn btn-danger" type="submit">Search</button>
                                 </span>
                                </form>
                              </div>
                            </div>
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Photo</th>
                                            <th>Id</th>
                                            <th>File Name</th>
                                            <th>Title</th>
                                            <th>Size</th>
                                            <th>Comments</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($photos as $photo): ?>
                                            <tr>
                                                <td><img class="admin-photo-thumbnail" src="<?php echo $photo->picture_path(); ?>" alt="">
                                                   <div class="actions_link">
                                                   <a class="delete_link" href="delete_photo.php?id=<?php echo $photo->id; ?>">Delete</a>
                                                   <a href="edit_photo.php?id=<?php echo $photo->id; ?>">Edit</a>
                                                   <a href="../photo.php?id=<?php echo $photo->id; ?>">View</a>
                                                   </div>
                                                </td>
                                                <td><?php echo $photo->id; ?></td>
                                                <td><?php echo $photo->filename; ?></td>
                                                <td><?php echo $photo->title; ?></td>
                                                <td><?php echo $photo->size; ?></td>
                                                <td>
                                                  <a href="comment_photo.php?id=<?php echo $photo->id;?>">
                                                  <?php 
                                                  $comments = Comment::find_the_comments($photo->id);
                                                  echo count($comments); 
                                                  ?>
                                                   </a> 
                                                  </td>
                                            </tr>
                                         <?php endforeach; ?>
                                    </tbody> <!--End of Table-->
                                </table>
                            </div>

                        </div>
                    </div>
                    <!-- /.row -->
             <div class="row text-center">
                  <ul class="pagination">
                      <?php 
                      if($paginate->page_total() > 1){
                        if($paginate->has_previous()){
                          echo "<li class='previous'><a href='photos.php?page={$paginate->previous()}'>Previous</a></li>";
                        }
                        for ($i=max(1,$paginate->current_page - 3); $i <= min($paginate->page_total() +3, $paginate->page_total()); $i++) { 
                            if($i == $paginate->current_page){
                                echo "<li class='active'><a href='photos.php?page={$i}'>$i</a></li>";
                            }else{
                                echo "<li><a href='photos.php?page={$i}'>$i</a></li>";
                              }
                          }
                        if($paginate->has_next()){
                          echo "<li class='next'><a href='photos.php?page={$paginate->next()}'>Next</a></li>";
                        }

                      } 
                      
                      ?>
                      
                  </ul>
              </div>
                </div>
                <!-- /.container-fluid -->
             
        </div>
        <!-- /#page-wrapper -->

  <?php include("includes/footer.php"); ?>