<?php include("includes/init.php"); ?>
<?php 
  if(!$session->is_signed_in()){
  redirect("login.php");
  } //redirection of page to login page if user not signed in
 ?>

 <?php 

if(empty($_GET["id"])){
  redirect("photos.php");
}
$photo = Photo::find_by_id($_GET["id"]);

if($photo){
   $photo->delete_photo();
   redirect("photos.php");
   $session->message("<div class='alert alert-danger' role='alert'> Photo <strong>{$photo->filename}</strong> has been deleted <button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>");
}else{
  redirect("photos.php");
}











?>