<?php include("includes/header.php"); ?>
<?php if(!$session->is_signed_in()){
  redirect("login.php");
  } //redirection of page to login page if user not signed in ?>
  <?php 
 
  $page = !empty($_GET["page"]) ? (int)$_GET["page"] : 1;
  $items_per_page = 5;
  $items_total_count = Comment::count_all();
  $paginate = new Paginate($page, $items_per_page, $items_total_count);

  $sql = "SELECT * FROM comments ";
  $sql .= "LIMIT {$items_per_page} ";
  $sql .= "OFFSET {$paginate->offset()}";
  $comments = Comment::find_by_query($sql);

   //$comments = Comment::find_all();
   
   ?>
        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <?php include "includes/top_nav.php";?> 

            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->

            <?php include "includes/side_nav.php";?>
            
            <!-- /.navbar-collapse -->

        </nav>

        <div id="page-wrapper">
             <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="row">
                        <div class="col-lg-12">
                            <h1 class="page-header">
                                Comments
                            </h1>
                            <?php echo $message; ?>
                            <div class="col-md-12">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            
                                            <th>ID</th>
                                            <th>Author</th>
                                            <th>Comment</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($comments as $comment): ?>
                                            <tr>
                                                <td><?php echo $comment->id; ?></td>
                                                <td><?php echo $comment->author; ?>
                                                <div class="actions_link">
                                                   <a class="delete_link" href="delete_comment.php?id=<?php echo $comment->id; ?>">Delete</a>
                                                  <a href="edit_comment.php?id=<?php echo $comment->id; ?>">Edit</a>
                                                </div>
                                                </td>
                                                <td><?php echo $comment->body; ?></td>
                                            </tr>
                                         <?php endforeach; ?>
                                    </tbody> <!--End of Table-->
                                </table>
                            </div>

                        </div>
                    </div>
                    <!-- /.row -->
             <div class="row text-center">
                  <ul class="pagination">
                   <?php 
                      if($paginate->page_total() > 1){
                        if($paginate->has_previous()){
                          echo "<li class='previous'><a href='comments.php?page={$paginate->previous()}'>Previous</a></li>";
                        }
                        for ($i=max(1,$paginate->current_page - 3); $i <= min($paginate->page_total() +3, $paginate->page_total()); $i++) { 
                            if($i == $paginate->current_page){
                                echo "<li class='active'><a href='comments.php?page={$i}'>$i</a></li>";
                            }else{
                                echo "<li><a href='comments.php?page={$i}'>$i</a></li>";
                              }
                          }
                        if($paginate->has_next()){
                          echo "<li class='next'><a href='comments.php?page={$paginate->next()}'>Next</a></li>";
                        }

                      } 
                      
                      ?>
                  </ul>
              </div>
                </div>
                <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

  <?php include("includes/footer.php"); ?>  