<?php include("includes/init.php"); ?>
<?php 
  if(!$session->is_signed_in()){
  redirect("login.php");
  } //redirection of page to login page if user not signed in
 ?>

 <?php 

if(empty($_GET["id"])){
  redirect("comments.php");
}
$comment = Comment::find_by_id($_GET["id"]);

if($comment){
   $comment->delete();
   redirect("comments.php");
   $session->message("<div class='alert alert-danger' role='alert'> Comment has been deleted by ID:{$comment->id}<button type='button' class='close' data-dismiss='alert' aria-label='Close'><span aria-hidden='true'>&times;</span></button></div>");
}else{
  redirect("comments.php");
}











?>